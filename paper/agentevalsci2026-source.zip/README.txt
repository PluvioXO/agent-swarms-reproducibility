AgentEvalSci 2026 extended-abstract submission
Updated 25 October 2026

UPLOAD
main.pdf is the extended abstract: two main pages followed by references.
Select Extended Abstract in OpenReview. The title and abstract are unchanged.
Author names and affiliations are included, as required by this venue.

SOURCE
main.tex is the current extended abstract. The earlier full paper is saved
in the repository history. appendix.tex and the figure assets are retained
for reference, but are not included in this extended-abstract PDF.
submission.txt and submission-metadata.json identify Extended Abstract.
The complete editable source ZIP includes the required template, fonts,
figures, licenses, metadata, and saved evidence.

BUILD
Run make with XeLaTeX, BibTeX, and latexmk installed. In Overleaf, select
XeLaTeX and main.tex. The official AES typography and margins are unchanged.

REPRODUCIBILITY
https://github.com/PluvioXO/agent-swarms-reproducibility
The reproducibility-v1.3 evidence snapshot covers eleven complementary studies:
26,648 retained trials, 316 cells, and 176 evaluation cells. Extended methods,
readable cells, recorded settings, operational accounting, provenance, and
an offline aggregate verifier are in the repository. The supplied controlled-
study summary has an explicit coverage note; complete supporting records
for the separate 8,400-trial study are not included.

Title and abstract text are preserved exactly. Remaining scientific support
is indexed in CONTROLLED-STUDY-TODO.txt and the repository coverage note.
Complete the real author/reviewer profiles, license, and applicable author
fields in OpenReview. Nothing has been submitted.

Official call: https://evalscience.org/2026fall-nyc/submissions/
Official template: https://github.com/agent-evalscience/AES-Latex-Template
