AgentEvalSci 2026 self-contained extended abstract
Updated 25 October 2026

UPLOAD
main.pdf contains two main pages plus one references page. No appendix.
Select Extended Abstract in OpenReview. Title and abstract are unchanged.
Figure 1 is the original three-panel results figure. Figure 2 is the
architecture/schedule diagram, replacing the main results table.

EDIT AND BUILD
Edit main.tex in place. Run make with XeLaTeX, BibTeX, and latexmk installed.
For Overleaf, upload the source ZIP, select XeLaTeX and main.tex, and preserve
fonts/, figures/, and assets/. Official AES typography and margins are unchanged.
The current source ZIP contains no appendix or separate cell-table TeX.
Unused supplementary sources are retained in backups and repository history.

CONTENT
The main text states study scope, widths 1/2/4/8/16 where tested, paired
analysis, resource-use counts, activation, policy confirmation, accounting
limits, and ongoing work. The original title and entire abstract block are
preserved exactly. No additional scientific material is appended to the PDF.
The source package also includes editing metadata, required licenses and
assets, and saved evidence; these are not additional PDF sections.

REPRODUCIBILITY
https://github.com/PluvioXO/agent-swarms-reproducibility
The reproducibility-v1.3 evidence snapshot covers eleven complementary studies:
26,648 retained trials, 316 cells, and 176 evaluation cells. The separate
controlled-study note identifies available summary information and missing
supporting records. Current paper files on main are the self-contained
extended abstract. Earlier manuscript versions remain in repository history.

The offline verifier checks saved aggregates, not original graders,
confidence intervals, or new model inference. Complete the real OpenReview
author/reviewer profiles, license, and applicable author fields before upload.
Nothing has been submitted.

Official call: https://evalscience.org/2026fall-nyc/submissions/
Official template: https://github.com/agent-evalscience/AES-Latex-Template

Final update: Funding and Interests removed at the author's request. Added width-8/16 pass counts, PlanBench and BBEH reversals, Countdown effects, and resource-use qualifications to fill the two-page main text. Title and abstract remain unchanged.
