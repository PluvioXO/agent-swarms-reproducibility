AgentEvalSci 2026 self-contained extended abstract
Updated 26 October 2026

UPLOAD
main.pdf contains two main pages plus one references page. No appendix.
Select Extended Abstract in OpenReview. Title is unchanged; the abstract is
condensed with all content retained. Both the cited Anna Karenina quotation
and its paper-specific adaptation precede the architecture diagram (Figure 1)
on page 1, between the abstract and diagram. Figure 2 is the
original three-panel results figure in the body, replacing the results table.

EDIT AND BUILD
Edit main.tex in place. Run make with XeLaTeX, BibTeX, and latexmk installed.
For Overleaf, upload the source ZIP, select XeLaTeX and main.tex, and preserve
fonts/, figures/, and assets/. Official AES typography and margins are unchanged.
The current source ZIP contains no appendix or separate cell-table TeX.
Unused supplementary sources are retained in backups and repository history.

CONTENT
The main text states study scope, widths 1/2/4/8/16 where tested, paired
analysis, resource-use counts, activation, policy confirmation, accounting
limits, and ongoing work. The original title is preserved exactly; the abstract is condensed with
all results, comparisons, and qualifications retained. No additional scientific material is appended to the PDF.
The source package also includes editing metadata, required licenses and
assets, and saved evidence; these are not additional PDF sections.

REPRODUCIBILITY
https://github.com/PluvioXO/agent-swarms-reproducibility
The reproducibility-v1.3 evidence snapshot covers eleven complementary studies:
26,648 retained trials, 316 cells, and 176 evaluation cells. The separate
controlled-study note identifies available summary information and missing
supporting records. Current paper files on main are the self-contained
extended abstract. Earlier manuscript versions remain in repository history.

The offline verifier checks saved aggregates, not original graders,
confidence intervals, or new model inference. Complete the real OpenReview
author/reviewer profiles, license, and applicable author fields before upload.
Nothing has been submitted.

Official call: https://evalscience.org/2026fall-nyc/submissions/
Official template: https://github.com/agent-evalscience/AES-Latex-Template

Final update: Funding and Interests removed at the author's request. Added width-8/16 pass counts, PlanBench and BBEH reversals, Countdown effects, and resource-use qualifications to fill the two-page main text. Title and scientific results remain unchanged; the abstract is condensed with all content retained.

Citation update: 16 research works cover sampling/aggregation, allocation, communication, task sources, deterministic generation, paired task-cluster bootstrap, and failure analysis. Efron (1979) and Field and Welsh (2007) support the resampling methods. The restored quotation adds a seventeenth reference, Tolstoy (2014). Two main pages plus one references page; no appendix.

26 October layout update: The cited Anna Karenina quotation and its paper-specific adaptation sit between the abstract and the architecture diagram (Figure 1) on page 1. The abstract is condensed with all content retained, as authorized to make this fit. The title and scientific results are unchanged. The results panel (Figure 2) remains on page 2. Two main pages plus one references page; clean compilation and visual review.

Page-two detail update: Restored independent/ring revision and controlled sequential feedback rules, the 26,648-trial calibration/evaluation split, paired task resampling with unadjusted study-specific intervals, the Luna graph-colouring ring contrast, and the seven Muse operational-zero qualification. Page one, figures, title and abstract are unchanged. Two main pages plus one references page; clean build and visual review.

Final package review, 26 October 2026: clean build from the source ZIP, 17 references, all fonts embedded, all 26,648 saved complementary-study trials verified, and public GitHub paper/source files checked against local copies. Preparation notes now use the live OpenReview deadline (26 October, 12:00 UTC) and current figure numbering; the obsolete appendix reference points to METHODS.md. The 8,400-trial controlled-study supporting-record gaps and author-only OpenReview fields remain.
