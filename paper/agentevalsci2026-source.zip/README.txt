AgentEvalSci 2026 short-paper submission
Updated 25 October 2026

STATUS
The supplied controlled-study protocol and headline results are included in
the main text. Available reproducibility materials are in the linked public
repository. Its coverage note identifies the controlled-study records and
detailed results absent from this snapshot. Add those supporting details and
complete the author-only OpenReview fields before submission.

UPLOAD
Use main.pdf as the single OpenReview submission PDF.
The PDF has six main pages, one references page, and three appendix pages
(10 pages total). References and appendices are outside the venue's 4-6 page
short-paper limit. Author identities are included as required.

EDIT
main.tex                  Main paper, controlled-study summary, and authors
appendix.tex              Essential complementary-study methods and caveats
CONTROLLED-STUDY-TODO.txt Remaining information and precise insertion points
references.bib            Research references and the cited Tolstoy edition
submission.txt            Copyable OpenReview text and author-only fields
submission-metadata.json  Matching title, abstract, keywords, and TL;DR

FORMAT AND BUILD
Official AES template in public mode: A4, 11 pt, bundled Open Sans,
AES logo, author-year references, and the template's margins and spacing.
Template assets, fonts, licenses, and notices are preserved.

From this folder with XeLaTeX, BibTeX, and latexmk installed:

    make

This runs the saved-outcome verifier before building the paper. In Overleaf,
upload the complete source ZIP, select XeLaTeX and main.tex, and preserve
fonts/ and assets/. Do not use pdfLaTeX.

Official call: https://evalscience.org/2026fall-nyc/submissions/
Official template: https://github.com/agent-evalscience/AES-Latex-Template

REPRODUCIBILITY MATERIALS
Repository: https://github.com/PluvioXO/agent-swarms-reproducibility
Snapshot: https://github.com/PluvioXO/agent-swarms-reproducibility/tree/reproducibility-v1.3
The full readable 176-cell evaluation table, extended methods, seven recorded
configuration objects, detailed resampling settings, operational accounting,
and reporting checklist are in the repository. The PDF retains essential
methods, primary findings, and interpretation caveats. The repository also
contains the supplied controlled-study summary with explicit evidence coverage.

This source package includes the eleven complementary studies' normalized
26,648 trials, 316 cell summaries, provenance hashes, compact graph details,
and the standard-library verifier:

    python3 verify_results.py

The verifier checks counts, recorded-token means, descriptive comparisons,
11 paired point estimates, worker activation, and PlanBench truncation. It
does not recompute confidence intervals, validate graders, or replay model
inference. The separate 8,400 controlled-study records are not included.
Full experimental archives, provider payloads, and historical reports remain
outside the concise peer-review package.

SCOPE
The parent AAAI manuscript is unchanged. No new model inference was performed.
The abstract and headline controlled-study results are accepted as supplied
by the author. main-3.pdf supplies the earlier eleven studies, not the separate
controlled study. A cited Tolstoy quotation and labeled study adaptation remain
below the abstract. Read CONTROLLED-STUDY-TODO.txt and submission.txt for the
remaining evidence and author-only fields. Nothing has been submitted.
