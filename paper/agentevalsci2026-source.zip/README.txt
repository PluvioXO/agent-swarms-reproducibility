AgentEvalSci 2026 — self-contained extended abstract
Updated 28 October 2026

CURRENT PAPER
main.pdf contains two main pages plus one references page, with no appendix.
The paper analyses eleven documented studies: 20,376 evaluation trials and
6,272 calibration trials across seven task families. Its findings concern
budget allocation, actual worker participation, baseline choice and ring
revision. The contribution is an empirical audit with three reporting checks:
execution feasibility, realized participation and competitive baselines. No additional experiment contributes to this version.

The title is unchanged. The abstract has been rewritten around these studies.
The cited Anna Karenina quotation and its paper-specific adaptation remain
between the abstract and architecture diagram (Figure 1). The architecture
is an editable vector diagram of the documented pipelines and output rules.
Figure 2 condenses all three original results panels into an editable vector
graphic, preserving the wider-cell counts, budget effects and activation data.
University emails display as {mn866, ay582}@bath.ac.uk. The Amazon affiliation
is retained; no Amazon email address is included.

EDIT AND BUILD
Edit main.tex in place. Run make with XeLaTeX, BibTeX and latexmk installed.
For Overleaf, upload the source ZIP, select XeLaTeX and main.tex, and retain
fonts/, figures/ and assets/. Figure 1 is figures/worker-schedules.tex and
uses TikZ. The official AES style, typography and margins are unchanged.

REPRODUCIBILITY
https://github.com/PluvioXO/agent-swarms-reproducibility
The evidence comprises 26,648 retained trials, 316 cells and 176 evaluation
cells. Pilots, smoke checks and specified superseded rows are excluded.
The scientific trial data and saved estimates are unchanged from the
reproducibility-v1.3 snapshot. Current paper files are on main; earlier
manuscripts remain in repository history.

The offline verifier checks saved aggregates and paired point estimates.
It does not independently regrade answers, recompute confidence intervals,
replay inference or verify complete provider billing. Model settings, task
sources, output selection, amendments and accounting limits are described
in the repository's concise METHODS.md and DATA.md.

SUBMISSION
Upload the single main.pdf to OpenReview as an Extended Abstract.
submission.txt and submission-metadata.json contain the matching abstract
and author details. Use the real author/reviewer profiles and choose the
submission license and presentation preference in the form.
The live invitation observed on 28 October gives a deadline of 28 October
2026 at 11:59 UTC / GMT. See submission.txt for the checked source.
Nothing has been submitted by this workflow.

Official call: https://evalscience.org/2026fall-nyc/submissions/
Official template: https://github.com/agent-evalscience/AES-Latex-Template
